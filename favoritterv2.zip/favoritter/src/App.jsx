import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Recipes from "./components/Recipes";
import RecipeDetail from "./components/RecipeDetail";

const App = () => {
  const [likedRecipes, setLikedRecipes] = useState(() => {
    const saved = localStorage.getItem("likedRecipes");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem("likedRecipes", JSON.stringify(likedRecipes));
  }, [likedRecipes]);

  const toggleLike = (id) => {
    setLikedRecipes((prev) =>
      prev.includes(id) ? prev.filter((rid) => rid !== id) : [...prev, id]
    );
  };

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            <Recipes likedRecipes={likedRecipes} toggleLike={toggleLike} />
          }
        />
        <Route path="/recipe/:id" element={<RecipeDetail />} />
      </Routes>
    </Router>
  );
};

export default App;
