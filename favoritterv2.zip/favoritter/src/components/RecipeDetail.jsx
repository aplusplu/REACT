import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";

const RecipeDetail = () => {
  const { id } = useParams();
  const [recipe, setRecipe] = useState(null);

  useEffect(() => {
    const fetchDetail = async () => {
      try {
        const res = await fetch(`https://dummyjson.com/recipes/${id}`);
        const data = await res.json();
        setRecipe(data);
      } catch (err) {
        console.error("Eroare la detalii:", err);
      }
    };

    fetchDetail();
  }, [id]);

  if (!recipe) return <p>Se încarcă detaliile...</p>;

  return (
    <div className="recipe-detail">
      <Link to="/">← Tilbage til opskrifter</Link>
      <h1>{recipe.name}</h1>
      <img src={recipe.image} alt={recipe.name} />
      <h3>Ingredienti:</h3>
      <ul>
        {recipe.ingredients.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
      <h3>Instruktioner:</h3>
      <p>{recipe.instructions}</p>
      <h4>Rating: {recipe.rating}</h4>
      <h4>Tilberedningstid: {recipe.cookTimeMinutes} minute</h4>
      <h4>Forberedelsestid: {recipe.prepTimeMinutes} minute</h4>
    </div>
  );
};

export default RecipeDetail;
