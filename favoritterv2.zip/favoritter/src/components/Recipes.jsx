import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Recipes = ({ likedRecipes, toggleLike }) => {
  const [recipes, setRecipes] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [mealFilter, setMealFilter] = useState("all");
  const [cuisineFilter, setCuisineFilter] = useState("all");

  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        const res = await fetch("https://dummyjson.com/recipes");
        const data = await res.json();

        // Adaugăm artificial câmpurile mealType și cuisine (API-ul nu le oferă)
        const enhanced = data.recipes.map((recipe) => ({
          ...recipe,
          mealType: ["breakfast", "lunch", "dinner"][
            Math.floor(Math.random() * 3)
          ],
          cuisine: ["asian", "italian", "indian", "mediterranean"][
            Math.floor(Math.random() * 4)
          ],
        }));

        setRecipes(enhanced);
        setFiltered(enhanced);
      } catch (err) {
        console.error("Eroare la fetch:", err);
      }
    };
    fetchRecipes();
  }, []);

  useEffect(() => {
    let result = [...recipes];

    if (mealFilter !== "all") {
      result = result.filter(
        (r) => r.mealType && r.mealType.toLowerCase() === mealFilter
      );
    }

    if (cuisineFilter !== "all") {
      result = result.filter(
        (r) => r.cuisine && r.cuisine.toLowerCase() === cuisineFilter
      );
    }

    if (searchTerm.trim()) {
      result = result.filter((r) =>
        r.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFiltered(result);
  }, [searchTerm, mealFilter, cuisineFilter, recipes]);

  const uniqueMealTypes = [
    ...new Set(recipes.map((r) => r.mealType).filter(Boolean)),
  ];
  const uniqueCuisines = [
    ...new Set(recipes.map((r) => r.cuisine).filter(Boolean)),
  ];

  return (
    <div className="recipes-list">
      <h1>Lækre Opskrifter</h1>

      {/* Căutare și filtre */}
      <div style={{ marginBottom: "2rem" }}>
        <input
          type="text"
          placeholder="Search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{
            padding: "0.5rem",
            fontSize: "1rem",
            marginRight: "1rem",
            borderRadius: "8px",
            border: "1px solid #ccc",
          }}
        />
        <select
          value={mealFilter}
          onChange={(e) => setMealFilter(e.target.value)}
        >
          <option value="all">Alle</option>
          {uniqueMealTypes.map((type) => (
            <option key={type} value={type.toLowerCase()}>
              {type}
            </option>
          ))}
        </select>

        <select
          value={cuisineFilter}
          onChange={(e) => setCuisineFilter(e.target.value)}
          style={{ marginLeft: "1rem" }}
        >
          <option value="all">Alle madretter</option>
          {uniqueCuisines.map((cuisine) => (
            <option key={cuisine} value={cuisine.toLowerCase()}>
              {cuisine}
            </option>
          ))}
        </select>
      </div>

      {/* Lista rețetelor filtrate */}
      <div className="grid">
        {filtered.map((recipe) => (
          <div key={recipe.id} className="recipe-card">
            <Link to={`/recipe/${recipe.id}`}>
              <div className="recipe-image-wrapper">
                <img src={recipe.image} alt={recipe.name} />
              </div>
              <h2>{recipe.name}</h2>
            </Link>
            <button onClick={() => toggleLike(recipe.id)}>
              {likedRecipes.includes(recipe.id) ? "💔 Unlike" : "❤️ Like"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Recipes;
